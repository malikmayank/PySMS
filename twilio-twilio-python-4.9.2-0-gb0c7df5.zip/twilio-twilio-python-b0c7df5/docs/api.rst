=================
API Documentation
=================

A complete API reference to the :data:`twilio` module.

.. toctree::
   :maxdepth: 1

   api/rest/index
   api/rest/resources
   api/rest/resources/task_router
   api/twiml
   api/util

